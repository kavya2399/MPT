package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackException;
public class FeedbackDAO implements IFeedbackDAO {
	Map<String,Integer> MathFeedbackMap=new HashMap<>();
	Map<String,Integer>EnglishFeedbackMap=new HashMap<>();
	Feedback fdbk =new Feedback();
	@Override
	public String acceptFeedback(String name,int rating,String subject)throws FeedbackException {
		// TODO Auto-generated method stub
		String topic=null;
		
		if(topic.equalsIgnoreCase("English"))
		{
		EnglishFeedbackMap.put(name, rating);
	}
		else if(topic.equalsIgnoreCase("Maths"))
		{
			MathFeedbackMap.put(name, rating);
		}
		
         return null;
}
	@Override
	public String FeedbackReport() {
		
		// TODO Auto-generated method stub
		return null;
	}
}
	