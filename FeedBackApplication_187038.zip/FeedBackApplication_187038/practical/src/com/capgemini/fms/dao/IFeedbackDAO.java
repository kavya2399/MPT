package com.capgemini.fms.dao;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackException;

public interface IFeedbackDAO {

public String acceptFeedback(String name, int rating, String subject)	throws FeedbackException;
public String FeedbackReport();
}
