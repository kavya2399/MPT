package com.capgemini.fms.service;

import com.capgemini.fms.bean.Feedback;

public interface IFeedbackService {

	public String acceptFeedback(String name,int rating,String subject) throws FeedbackException;
	public String FeedbackReport();
	
	
}
