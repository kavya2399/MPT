package com.capgemini.fms.service;
import com.capgemini.fms.service.FeedbackValidation;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.dao.IFeedbackDAO;
import com.capgemini.fms.service.FeedbackException;
public  class FeedbackService implements IFeedbackService{
	IFeedbackDAO dao=new FeedbackDAO();

	@Override
	public String acceptFeedback(String name, int rating, String subject)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String FeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}


	
	
	

}
