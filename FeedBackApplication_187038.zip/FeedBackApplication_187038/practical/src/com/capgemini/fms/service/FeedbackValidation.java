package com.capgemini.fms.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackException;
public class FeedbackValidation {
		public boolean result=false;
		void validator(Feedback fdbk) throws FeedbackException {
			validateSubject(fdbk.getTopic());
			
		}
		public void  validateSubject(String topic)throws FeedbackException  {
			Pattern p=Pattern.compile("Maths");
			Pattern p1=Pattern.compile("English");
			Matcher m=p.matcher(topic);
//			Matcher m1=p1.matcher(topic)
			if(m.find()) {
				result=true;
			}
			else {
				throw new FeedbackException("Invalid Subject");
		}
		}
}
		
		
			
			
			
			
			
			
			
			
			
			
			
		
			
			
			
			
			
			