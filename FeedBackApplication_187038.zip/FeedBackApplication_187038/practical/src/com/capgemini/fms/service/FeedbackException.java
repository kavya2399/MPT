package com.capgemini.fms.service;
@SuppressWarnings("serial")
public class FeedbackException extends Exception {
	public FeedbackException(String msg) {
		System.out.println(msg);
	}

}