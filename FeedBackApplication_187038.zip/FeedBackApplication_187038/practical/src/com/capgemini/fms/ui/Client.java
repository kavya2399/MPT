package com.capgemini.fms.ui;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackException;
import com.capgemini.fms.service.FeedbackService;
import com.capgemini.fms.service.IFeedbackService;

import java.util.*;
public class Client          
 // class to get the details of the teacher
{
static IFeedbackService service=new FeedbackService();
// object creation to pass the value to the service class
public static void showMenu()
{
	System.out.println("1.Add Feedback");
	System.out.println("2.Print Feedback");
	System.out.println("3.Exit");
}
public static void main(String args[])throws FeedbackException
{
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	int choice;
	while(true) {
	showMenu();
	choice=sc.nextInt();
	switch(choice) 
	{
	case 1:
//		this case to get the details of the teacher
	{
		try
		{
		System.out.println("Enter Teacher Name:");
		String teacherName=sc.next();
		System.out.println("Enter SubjectName:");
		String topic=sc.next();
		System.out.println("Enter Rating between 1 and 5:");
		int rating=sc.nextInt();
        Feedback fb=new Feedback();
         fb.getTeacherName();
		fb.getTopic();
		fb.getRating();
	service.acceptFeedback(teacherName,rating,topic);
		System.out.println("Feedback added");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		break;
	}
	case 2:
	{
		//to get the values of the teacher and then display the feedback
		System.out.println("Teacher Name");
			String teacherName=sc.next();
			System.out.println("Feedback Rating");
			String fdbk=service.FeedbackReport();
			break;
}
	case 3:
	{
		System.out.println("Thank you ");
	}
}
}
}
}


