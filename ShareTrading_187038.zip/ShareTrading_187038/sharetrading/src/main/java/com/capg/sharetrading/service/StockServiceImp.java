package com.capg.sharetrading.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.sharetrading.exceptions.StockException;
import com.capg.sharetrading.model.Stock;
import com.capg.sharetrading.repository.StockRepo;





@Service
public class StockServiceImp implements StockService {
	@Autowired
StockRepo stockRepository;

	@Override
	public List<Stock> createStock(Stock st) throws StockException {
		// TODO Auto-generated method stub
		try {
			 stockRepository.save(st);
		        return stockRepository.findAll();
		        }catch(Exception e) {
		            throw new StockException(e.getMessage());
		        }
	}



  @Override 
 public List<Stock> updateStock(String id,Stock st) throws StockException {
	  
  try{ 
  Optional<Stock> optional=stockRepository.findById(id);
  if(optional.isPresent()) {
	  Stock stock=optional.get();
  stock.setName(st.getName());
  stock.setQuantity(st.getQuantity());
  stock.setPrice(st.getPrice());
  stock.setAmount(st.getAmount());
  stockRepository.save(stock); 
  return viewAllStock(); } 
  else {
	  throw new StockException("Stock with Id"+id+" is not  existing please enter an valid id "); } 

  }

catch(Exception e) 
{ 
throw new StockException(e.getMessage()); 
}
  }

  
  @Override
  public void deleteStock(int id) throws StockException {

  try { 
	  stockRepository.deleteById(id); 
  }
  catch(Exception e) {
	  throw new StockException(e.getMessage()); 
	  }
  
 }
  
  @Override public List<Stock> viewAllStock() throws StockException {
	  try { return stockRepository.findAll(); }
  catch(Exception e) 
	  { 
	  throw new StockException(e.getMessage()); 
	  }
  
 }
  
 @Override
 public List<Stock> findSingleStock(String id) throws StockException { 
   try {
	   return (List<Stock>) stockRepository.findAllById(id).get();
	   } 
   catch (Exception ex) { 
	   throw new StockException(ex.getMessage());
	   }
  
 }

  }
