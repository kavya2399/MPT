package com.capg.sharetrading.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.sharetrading.exceptions.StockException;
import com.capg.sharetrading.model.Stock;
import com.capg.sharetrading.service.StockService;





@RestController
public class StockController {

	@Autowired 
	StockService service;
	
	@RequestMapping(value="/stock" ,method=RequestMethod.POST)
	public List<Stock> createStock(@RequestBody Stock st)throws StockException{
		return service.createStock(st);
	}
		
		 @PutMapping("/stock/{id}") 
		 public List<Stock> updateStock(@PathVariable String id, @RequestBody Stock st) throws StockException{
			 return service.updateStock(id, st); 
		 }
		  
		  @DeleteMapping("/stock/{id}") 
		  public ResponseEntity<String> deleteStock(@PathVariable int id) throws StockException {
		  service.deleteStock(id); 
		  return new ResponseEntity<String> ("Stock with id "+id+" deleted successfullyy",HttpStatus.OK);
		  }
		  
		  
		  @RequestMapping("/stock") 
		  public List <Stock> viewAllStock()
				  throws  StockException { 
			  return service.viewAllStock();
				  }
		 
		@RequestMapping(value="/stock/{id}" )
		public List<Stock> FindSingleStock(@PathVariable String id) throws StockException{
		return service.findSingleStock(id);
	    }
		
}
	
