package com.capg.sharetrading.service;

import java.util.List;

import com.capg.sharetrading.exceptions.StockException;
import com.capg.sharetrading.model.Stock;

public interface StockService {

	public List<Stock> createStock(Stock st) throws StockException;
//	public List<Stock> updateStock(int id,Stock st) throws StockException;
	public void deleteStock(int id) throws StockException;
	public List<Stock> viewAllStock() throws StockException;
	public List<Stock> findSingleStock(String id)throws StockException;
	public List<Stock> updateStock(String id, Stock st) throws StockException;
	
	
	
	
}
