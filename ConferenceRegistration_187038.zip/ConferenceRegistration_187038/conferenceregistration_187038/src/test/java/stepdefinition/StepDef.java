package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementlocators.ElementLocators;

public class StepDef {
	@Given("^Conference Registration$")
	public void conference_Registration() throws Throwable {
		pagefactory.PageFact.openbrowser("file:///C:/Users/ka16/Desktop/kavya.selinum/conferenceregistration_187038/target/ConferenceRegistartion.html");
	}

	@When("^User come to register page$")
	public void user_come_to_register_page() throws Throwable {
//	  pagefactory.PageFact.verifyTitle();
	}

	@When("^user validate firstname$")
	public void user_validate_firstname() throws Throwable {
	 pagefactory.PageFact.clickmethod(elementlocators.ElementLocators.next);
	 Thread.sleep(1000);
	 pagefactory.PageFact.alertHandler();
	 pagefactory.PageFact.sendvalue(elementlocators.ElementLocators.firstName, "kavya");
	}

	@When("^user validate lastname$")
	public void user_validate_lastname() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.lastName, "a");
	}
	@When("^user validate email$")
	public void user_validate_email() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.email, "kkk@gmail.com");
	}
	

	@When("^user validate contactnumber$")
	public void user_validate_contactnumber() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.contactNo, "9876543212");
	}
	

	@When("^user select number of people attending$")
	public void user_select_number_of_people_attending() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.select(ElementLocators.numberOfPeople,"1");
	}
	

	@When("^user validate buildingname and roomno$")
	public void user_validate_buildingname_and_roomno() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.buildingName, "joythi");
	}

	@When("^user validate areaname$")
	public void user_validate_areaname() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.areaName, "navalur");
	}

	@When("^user select city$")
	public void user_select_city() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.select(ElementLocators.city,"Chennai");
	}

	@When("^user select state$")
	public void user_select_state() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.select(ElementLocators.state,"Tamilnadu");
	}

	@When("^select member$")
	public void select_member() throws Throwable {
		 pagefactory.PageFact.clickmethod(ElementLocators.next);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.clickmethod(ElementLocators.memberStatus);

	}

	@Then("^Click on Next button$")
	public void click_on_Next_button() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.next);
	   
	}

	@Given("^Payment Details$")
	public void payment_Details() throws Throwable {
	}

	@When("^User come to payment page$")
	public void user_come_to_payment_page() throws Throwable {
		pagefactory.PageFact.alertHandler();
	}


	@When("^user validates cardholder name$")
	public void user_validates_cardholder_name() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.makePayment);
		Thread.sleep(1000);
		 pagefactory.PageFact.alertHandler();
		 
		 pagefactory.PageFact.sendvalue(ElementLocators.cardHolderName, "kavss");
	}


	@When("^user validates debitcard number$")
	public void user_validates_debitcard_number() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.makePayment);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.cardNumber, "1234567890");
	}

	@When("^user validates cvv$")
	public void user_validates_cvv() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.makePayment);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.cvv, "123");
	}


	@When("^user validates expire month$")
	public void user_validates_expire_month() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.makePayment);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.expiryMon, "09");
	}

	

	@When("^user validates expire year$")
	public void user_validates_expire_year() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.makePayment);
		 pagefactory.PageFact.alertHandler();
		 Thread.sleep(1000);
		 pagefactory.PageFact.sendvalue(ElementLocators.expiryYear, "2098");
	}


	@When("^Click makepayment button$")
	public void click_makepayment_button() throws Throwable {
		pagefactory.PageFact.clickmethod(ElementLocators.makePayment);
		 pagefactory.PageFact.alertHandler();
		 
	}

	@Then("^User is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
	   
	}

	@Then("^Browser is closed$")
	public void browser_is_closed() throws Throwable {
	  pagefactory.PageFact.close();
	}


}
