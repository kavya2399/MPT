package elementlocators;

import org.openqa.selenium.By;

public class ElementLocators {

	public static By loginTitle=By.xpath("//h1[text()='Conference Registration ']");
	public static By firstName=By.xpath("//input[@name='txtFN']");
	public static By lastName=By.xpath("//input[@name='txtLN']");
	public static By email=By.xpath("//input[@name='Email']");
	public static By contactNo=By.xpath("//input[@name='Phone']");
	public static By numberOfPeople=By.xpath("//select[@name='size']");
	public static By buildingName=By.xpath("//input[@name='Address']");
	public static By areaName=By.xpath("//input[@name='Address2']");
	public static By city=By.xpath("//select[@name='city']");
	public static By state=By.xpath("//select[@name='state']");
	public static By memberStatus=By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input");
    public static By next=By.xpath("/html/body/form/table/tbody/tr[14]/td/a");
	public static By cardHolderName=By.id("txtCardholderName");
	public static By cardNumber=By.id("txtDebit");
	public static By cvv=By.id("txtCvv");
	public static By expiryMon=By.id("txtMonth");
	public static By expiryYear=By.id("txtYear");
	public static By makePayment=By.id("btnPayment");
}
