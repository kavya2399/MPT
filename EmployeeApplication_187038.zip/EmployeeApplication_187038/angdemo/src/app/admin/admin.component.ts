import { Component, OnInit } from '@angular/core';
import { AddempComponent } from '../addemp/addemp.component';
import { EmplistComponent } from '../emplist/emplist.component';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
