import { Component, OnInit } from '@angular/core';
import employeedetails from '../../employeedetails/employee.json'
@Component({
  selector: 'app-addemp',
  templateUrl: './addemp.component.html',
  styleUrls: ['./addemp.component.css']
})
export class AddempComponent implements OnInit {

idvalidation=false
namevalidation=false
emailvalidation=false
phonevalidation=false
 constructor() { }
data=employeedetails
  ngOnInit() {
  }
  // method to add an employee
  // method to validate an employee
  validate(addEmployee)
  {

    // this line is to display the details of the employee in the console

    console.log(addEmployee.id + addEmployee.name +addEmployee.email + addEmployee.phone)   
    //push is to add the details of an employee
    this.data.push(addEmployee)
 if(!addEmployee.id)
 {
   this.idvalidation=true
   return
 }
 else{
   this.idvalidation=false
 }
 if(!addEmployee.name)
 {
   this.namevalidation=true
   return
 }
 else{
   this.namevalidation=false
 }
 if(!addEmployee.email)
 {
   this.emailvalidation=true
   return
 }
 else{
   this.emailvalidation=false
 }
  if(!addEmployee.phone)
 {
   this.phonevalidation=true
   return
 }
 else{
   this.phonevalidation=false
 }
}


}
