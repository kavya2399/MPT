import { Component, OnInit } from '@angular/core';
import employeedetails from '../../employeedetails/employee.json';
import { AddempComponent } from '../addemp/addemp.component';
@Component({
  selector: 'app-emplist',
  templateUrl: './emplist.component.html',
  styleUrls: ['./emplist.component.css']
})
export class EmplistComponent implements OnInit {
data=employeedetails
  constructor() { }

  ngOnInit() {
  }
  // delete method to delete the employees 
  delete(i){
    // splice method is used to delete the row which we need to delete
    this.data.splice(i,1)
    
  }
}
