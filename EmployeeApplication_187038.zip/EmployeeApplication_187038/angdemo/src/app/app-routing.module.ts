import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddempComponent } from './addemp/addemp.component';
import { EmplistComponent } from './emplist/emplist.component';
const routes: Routes = [

{
  path:'emplist',
  component:EmplistComponent
},


{
  path:'addemp',
  component:AddempComponent
}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
