package elementlocator;

import org.openqa.selenium.By;

public class ElementLocator {
	public static By username=By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input");
	public static By password=By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input");
	public static By btn=By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input");
	public static By RegisterLink=By.linkText("Register");
	public static By LinkText=By.linkText("REGISTER");
	public static By FirstName=By.xpath("//input[@name='txtFN']");
	public static By LastName=By.xpath("//input[@name='txtLN']");
	public static By phone=By.xpath("//input[@name='Phone']");
	public static By email=By.xpath("//input[@name='Email']");
	public static By address=By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea");
	public static By city=By.xpath("/html/body/div/div/form/table/tbody/tr[7]/td[2]/select");
	public static By state=By.xpath("/html/body/div/div/form/table/tbody/tr[8]/td[2]/select");
	public static By guestcount=By.xpath("/html/body/div/div/form/table/tbody/tr[10]/td[2]/select");
	public static By cardholdername=By.xpath("//input[@id='txtCardholderName']");
	public static By debitcard=By.xpath("//input[@name='debit']");
	public static By cvv=By.xpath("//input[@name='cvv']");
	public static By expireMonth=By.xpath("//input[@name='month']");
	public static By year=By.xpath("//input[@name='year']");
	public static By submit=By.xpath("//input[@id='btnPayment']");

}
