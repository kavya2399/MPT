package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class steps {
	@Given("^The user is on login page$")
	public void the_user_is_on_login_page() throws Throwable {
	   pagefactpact.Pagefactory.openbrowser("file:///C:/Users/ka16/Desktop/kavya.selinum/hotelloginform/target/login.html");
	}

	@Given("^Send the username$")
	public void send_the_username() throws Throwable {
	    pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.username,"capgemini");
	}

	@Given("^Send the password$")
	public void send_the_password() throws Throwable {
		  pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.password,"capg1234");
	}

	@Then("^User login succesfully$")
	public void user_login_succesfully() throws Throwable {
		  pagefactpact.Pagefactory.clickmethod(elementlocator.ElementLocator.btn);
	}

	@Given("^The User is on Hotel register page$")
	public void the_User_is_on_Hotel_register_page() throws Throwable {
	   
	}

	@Given("^Send First name$")
	public void send_First_name() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.FirstName, "sowndarya");
	}

	@Given("^Send the last name$")
	public void send_the_last_name() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.LastName,"j");
	}

	@Given("^Send Email$")
	public void send_Email() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.email,"xxx@gmail.com");
		
	}

	@Given("^Send phone number$")
	public void send_phone_number() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.phone,"8907654359");
	}

	@Given("^Send address$")
	public void send_address() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.address,"cbe");
	}

	@Given("^Select a city$")
	public void select_a_city() throws Throwable {
		pagefactpact.Pagefactory.select(elementlocator.ElementLocator.city,"Chennai");
	}

	@Given("^Select a state$")
	public void select_a_state() throws Throwable {
		pagefactpact.Pagefactory.select(elementlocator.ElementLocator.state,"Tamilnadu");
	}

	@Given("^Select a no of guest$")
	public void select_a_no_of_guest() throws Throwable {
		pagefactpact.Pagefactory.select(elementlocator.ElementLocator.guestcount,"1");
	}

	@Given("^send cardholdername$")
	public void send_cardholdername() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.cardholdername,"kavss");
	}

	@Given("^Send debitcardnumber$")
	public void send_debitcardnumber() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.debitcard,"1234567890");
	}

	@Given("^Send cvv$")
	public void send_cvv() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.cvv,"234");
		
	}

	@Given("^Send expiry month$")
	public void send_expiry_month() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.expireMonth,"03/12");
	}

	@Given("^Send year$")
	public void send_year() throws Throwable {
		pagefactpact.Pagefactory.sendvalue(elementlocator.ElementLocator.year,"05/25");
		
	}

	@Given("^Click submit button$")
	public void click_submit_button() throws Throwable {
		pagefactpact.Pagefactory.clickmethod(elementlocator.ElementLocator.submit);
	}

	@Then("^User is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
		
	}

	@Then("^Browser is closed$")
	public void browser_is_closed() throws Throwable {
		pagefactpact.Pagefactory.close();
	}



}
